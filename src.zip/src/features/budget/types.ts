export interface BudgetAlert {
  category: string;
  budget: number;
  spent: number;
  exceededBy: number;
}
