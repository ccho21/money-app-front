export default function Divider() {
    return (
      <div className="w-full border-t border-border my-2" />
    );
  }