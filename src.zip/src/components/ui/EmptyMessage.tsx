export default function EmptyMessage() {
  return (
    <p className='text-center mt-10 text-gray-400 py-3 pb-12'>
      데이터가 없습니다
    </p>
  );
}
