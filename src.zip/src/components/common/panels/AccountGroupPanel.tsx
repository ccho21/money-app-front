'use client';

export default function AccountGroupPanel() {
  return (
    <div className="p-2">
      <p className="text-sm text-gray-700 dark:text-gray-200">계좌 그룹 설정 (Account Group Panel)</p>
    </div>
  );
}
