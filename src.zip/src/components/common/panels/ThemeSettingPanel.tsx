'use client';

export default function ThemeSettingPanel() {
  return (
    <div className="p-2">
      <p className="text-sm text-gray-700 dark:text-gray-200">테마 설정 (Theme Setting) 패널입니다.</p>
    </div>
  );
}
