'use client';

export default function SubCurrencyPanel() {
  return (
    <div className="p-2">
      <p className="text-sm text-gray-700 dark:text-gray-200">보조 통화 (Sub Currency) 설정 패널입니다.</p>
    </div>
  );
}
