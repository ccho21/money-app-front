'use client';

export default function BackupResetPanel() {
  return (
    <div className="p-2">
      <p className="text-sm text-gray-700 dark:text-gray-200">백업 / 복원 / 초기화 설정 패널입니다.</p>
    </div>
  );
}
