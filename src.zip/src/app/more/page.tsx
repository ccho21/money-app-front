export default function MorePage() {
    return (
      <div className="p-4 pt-8 text-center text-xl font-semibold">
        ⋯ More Page (설정, 기타 기능)
      </div>
    );
  }