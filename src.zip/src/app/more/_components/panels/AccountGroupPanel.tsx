'use client';

export default function AccountGroupPanel() {
  return (
    <div className='p-4 bg-surface text-foreground'>
      <p className='text-sm text-muted-foreground'>
        계좌 그룹 설정 (Account Group Panel)
      </p>
    </div>
  );
}
