export default function AccountsPage() {
    return (
      <div className="p-4 pt-8 text-center text-xl font-semibold">
        💰 Accounts Page (계좌 목록/잔액 관리)
      </div>
    );
  }