'use client';

import { useEffect, useState } from 'react';

interface BudgetBoxProps {
  year: number;
  month: number;
}

interface BudgetItem {
  categoryId: string;
  categoryName: string;
  budget: number;
  spent: number;
  remaining: number;
  rate: number;
}

interface BudgetSummary {
  totalBudget: number;
  totalSpent: number;
  totalRemaining: number;
  items: BudgetItem[];
}

export default function BudgetBox({ year, month }: BudgetBoxProps) {
  const [data, setData] = useState<BudgetSummary | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchBudget = async () => {
      try {
        const res = await fetch(
          `/api/analysis/budgets?year=${year}&month=${month}`,
          { credentials: 'include' }
        );
        if (!res.ok) throw new Error('Failed to fetch budget data');

        const result: BudgetSummary = await res.json();
        setData(result);
      } catch (err) {
        setError('불러오기 실패');
      } finally {
        setLoading(false);
      }
    };

    fetchBudget();
  }, [year, month]);

  if (loading) return <div className='text-sm'>불러오는 중...</div>;
  if (error || !data)
    return <div className='text-sm text-red-500'>{error}</div>;

  const { totalBudget, totalSpent, totalRemaining } = data;
  const percent =
    totalBudget > 0 ? Math.round((totalSpent / totalBudget) * 100) : 0;

  return (
    <div className='rounded-xl border px-4 py-3 bg-white dark:bg-zinc-900 mt-4'>
      <h2 className='text-md font-semibold mb-3'>Budget</h2>

      <div className='text-sm text-gray-700 dark:text-gray-300 space-y-2'>
        <div className='flex items-center justify-between'>
          <span>Total Budget</span>
          <span className='font-medium'>${totalBudget.toFixed(2)}</span>
        </div>

        <Progress
          value={percent}
          className='h-3 bg-gray-200 dark:bg-zinc-800'
        />

        <div className='flex items-center justify-between text-xs'>
          <span className='text-blue-600 dark:text-blue-400 font-medium'>
            {totalSpent.toFixed(2)}
          </span>
          <div className='flex items-center gap-1'>
            <span className='bg-gray-100 dark:bg-zinc-700 px-2 py-0.5 rounded-full'>
              Today
            </span>
            <span className='text-gray-500 dark:text-gray-400'>
              {totalRemaining.toFixed(2)}
            </span>
            <span className='ml-1 font-semibold text-gray-800 dark:text-gray-200'>
              {percent}%
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
