import BudgetView from '../_components/BudgetView';

export default function BudgetPage() {
  return <BudgetView />;
}