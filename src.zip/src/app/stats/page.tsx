export default function StatsPage() {
    return (
      <div className="p-4 pt-8 text-center text-xl font-semibold">
        📊 Stats Page (분석/통계 뷰)
      </div>
    );
  }