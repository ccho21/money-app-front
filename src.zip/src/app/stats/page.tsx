export default function StatsPage() {
  return <></>;
}
