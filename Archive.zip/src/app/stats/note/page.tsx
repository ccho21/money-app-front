import NoteView from '../_components/NoteView';

export default function NotePage() {
  return <NoteView />;
}
