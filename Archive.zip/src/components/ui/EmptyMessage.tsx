'use client';

export default function EmptyMessage() {
  return (
    <p className='text-center text-muted text-sm py-12'>데이터가 없습니다</p>
  );
}
