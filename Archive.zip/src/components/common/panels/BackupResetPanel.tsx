'use client';

export default function BackupResetPanel() {
  return (
    <div className='p-4 bg-surface text-foreground'>
      <p className='text-sm text-muted-foreground'>
        백업 / 복원 / 초기화 설정 패널입니다.
      </p>
    </div>
  );
}
