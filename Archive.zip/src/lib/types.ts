export interface SummaryItem {
    label: string;
    value: number;
    color?: string;
    prefix: string;
  }
  