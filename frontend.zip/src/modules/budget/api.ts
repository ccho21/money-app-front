import { get, post, put } from '@/common/api';
import { buildQuery } from '@/shared/util/buildQuery';
import type {
  BudgetCategoryListResponseDTO,
  BudgetCategoryItemDTO,
  BudgetCategoryCreateRequestDTO,
  BudgetCategoryUpdateRequestDTO,
  BudgetGroupItemDTO,
  BudgetGroupSummaryDTO,
} from './types';
import type { DateFilterParams } from '@/common/types';

// ✅ [GET] /budgets/by-category → 카테고리별 예산 항목 조회
export const fetchBudgetByCategoryAPI = (params: DateFilterParams) => {
  const query = buildQuery(params);
  return get<BudgetCategoryListResponseDTO>(`/budgets/by-category?${query}`);
};

// ✅ [POST] /budgets/by-category → 예산 항목 생성
export const createBudgetCategoryAPI = (
  payload: BudgetCategoryCreateRequestDTO
) => {
  return post<BudgetCategoryItemDTO, BudgetCategoryCreateRequestDTO>(
    '/budgets/by-category',
    payload
  );
};

// ✅ [PUT] /budgets/by-category/:id → 예산 항목 수정
export const updateBudgetCategoryAPI = (
  id: string,
  payload: BudgetCategoryUpdateRequestDTO
) => {
  return put<BudgetCategoryItemDTO, BudgetCategoryUpdateRequestDTO>(
    `/budgets/by-category/${id}`,
    payload
  );
};

// ✅ [POST] /budgets/by-category/:categoryId → 그룹 예산 조회
export const fetchGroupedBudgetCategoryAPI = (
  categoryId: string,
  params: DateFilterParams
) => {
  return post<BudgetGroupItemDTO, DateFilterParams>(
    `/budgets/by-category/${categoryId}`,
    params
  );
};

// ✅ [GET] /budgets/summary → 예산 요약
export const fetchBudgetSummaryAPI = (params: DateFilterParams) => {
  const query = buildQuery(params);
  return get<BudgetGroupSummaryDTO>(`/budgets/summary?${query}`);
};
