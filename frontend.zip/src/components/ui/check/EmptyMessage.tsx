'use client';

export default function EmptyMessage() {
  return (
    <p className='text-sm text-muted text-center py-20'>📭 No data available</p>
  );
}
