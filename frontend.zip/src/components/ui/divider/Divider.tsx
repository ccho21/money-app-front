export default function Divider() {
  return <div className="h-px w-full bg-gray-200" />
}