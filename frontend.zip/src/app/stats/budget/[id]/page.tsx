'use client';

import { useEffect, useMemo } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { parseISO, startOfDay } from 'date-fns';

import { useStatsStore } from '@/modules/stats/store';
import { useFilterStore } from '@/stores/useFilterStore';
import { useUIStore } from '@/stores/useUIStore';

import { fetchBudgetSummary, fetchBudgetDetail } from '@/modules/stats/hooks';

import { CategoryType } from '@/modules/category/types';

import SummaryBox from '@/components/stats/SummaryBox';
import TransactionGroup from '@/components/transaction/TransactionGroup';
import Panel from '@/components/ui/check/Panel';
import ComposedChart from '@/components/ui/check/ComposedChart';
import EmptyMessage from '@/components/ui/check/EmptyMessage';
import { useShallow } from 'zustand/shallow';

export default function StatsBudgetDetailPage() {
  const { id: categoryId } = useParams();
  const router = useRouter();

  const { groupBy, transactionType } = useFilterStore((s) => s.query);
  const { getDateRangeKey, setQuery } = useFilterStore();
  const [startDate, endDate] = getDateRangeKey().split('_');

  const params = useMemo(
    () => ({
      startDate,
      endDate,
      type: transactionType as CategoryType,
      groupBy,
    }),
    [startDate, endDate, groupBy, transactionType]
  );

  const { budgetSummary, budgetDetail, isLoading, setBudgetDetail } =
    useStatsStore(
      useShallow((s) => ({
        budgetSummary: s.budgetSummary,
        budgetDetail: s.budgetDetail,
        isLoading: s.isLoading,
        setBudgetDetail: s.setBudgetDetail,
      }))
    );

  const setTopNav = useUIStore((s) => s.setTopNav);
  const resetTopNav = useUIStore((s) => s.resetTopNav);

  useEffect(() => {
    (async () => {
      if (!categoryId) return;

      const data = await fetchBudgetSummary(String(categoryId), params);
      const exists = data.items.find((d) => d.isCurrent);
      if (exists?.income || exists?.expense) {
        fetchBudgetDetail(String(categoryId), { ...params, groupBy: 'daily' });
      } else {
        setBudgetDetail(null);
      }
    })();
  }, [categoryId, params]);

  useEffect(() => {
    setTopNav({
      title: 'Budget',
      onBack: () => router.back(),
    });
    return () => resetTopNav();
  }, [setTopNav, resetTopNav, budgetSummary, router]);

  const chartData = useMemo(() => {
    if (!budgetSummary?.items) return [];
    return budgetSummary.items.map((item) => ({
      month: item.label,
      startDate: item.rangeStart,
      endDate: item.rangeEnd,
      value: transactionType === 'expense' ? item.expense : item.income,
      isCurrent: item.isCurrent,
    }));
  }, [budgetSummary, transactionType]);

  const summaryData = useMemo(() => {
    if (!budgetSummary || !budgetSummary.items.length) {
      return { budgetAmount: 0, expense: 0, income: 0, ramaining: 0 };
    }

    const current = budgetSummary.items.find((item) => item.isCurrent);
    if (!current) {
      return { budgetAmount: 0, expense: 0, income: 0, ramaining: 0 };
    }
    const budgetAmount = current.budgetAmount ?? 0;
    return {
      budgetAmount: budgetAmount,
      income: current.income,
      expense: current.expense,
      ramaining: budgetAmount - current.expense,
    };
  }, [budgetSummary]);

  if (isLoading) {
    return <p className='text-center mt-10 text-muted'>Loading...</p>;
  }

  return (
    <div className='space-y-4'>
      {/* 요약 정보 */}
      {budgetSummary && (
        <Panel>
          <SummaryBox
            items={[
              {
                label: 'Budget',
                value: summaryData.budgetAmount,
                color: 'text-primary',
                prefix: '$',
              },
              {
                label: 'Exp.',
                value: summaryData.expense,
                color: 'text-error',
                prefix: '$',
              },
              {
                label: 'Remaining',
                value: summaryData.ramaining,
                color: budgetSummary.summary?.isOver
                  ? 'text-error'
                  : 'text-foreground',
                prefix: '$',
              },
            ]}
          />
        </Panel>
      )}

      {/* 바 차트 */}
      {chartData.length > 0 && (
        <Panel>
          <div className='w-full h-36'>
            <ComposedChart
              data={chartData}
              onSelect={(startDate) => {
                setQuery({ date: startOfDay(parseISO(startDate)) });
              }}
            />
          </div>
        </Panel>
      )}

      {/* 거래 리스트 */}
      {budgetDetail?.items.length ? (
        <Panel>
          <div className='space-y-4'>
            {budgetDetail.items.map((group, i) => (
              <TransactionGroup
                key={group.label + i}
                label={group.label}
                rangeStart={group.rangeStart}
                rangeEnd={group.rangeEnd}
                groupIncome={group.groupIncome}
                groupExpense={group.groupExpense}
                group={group}
              />
            ))}
          </div>
        </Panel>
      ) : (
        <EmptyMessage />
      )}
    </div>
  );
}
