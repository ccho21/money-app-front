'use client';

export default function SubCurrencyPanel() {
  return (
    <div className='p-4 bg-surface text-foreground'>
      <p className='text-sm text-muted'>
        보조 통화 (Sub Currency) 설정 패널입니다.
      </p>
    </div>
  );
}
