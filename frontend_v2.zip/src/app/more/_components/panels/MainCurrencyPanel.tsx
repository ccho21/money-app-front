'use client';

export default function MainCurrencyPanel() {
  return (
    <div className='p-4 bg-surface text-foreground'>
      <p className='text-sm text-muted-foreground'>
        기본 통화 (Main Currency) 설정 패널입니다.
      </p>
    </div>
  );
}
