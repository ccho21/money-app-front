"use client";

import StatsView from "./_components/StatsView";


export default function StatsPage() {
  return <StatsView />;
}