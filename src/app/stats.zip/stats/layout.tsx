'use client'; // ⭐ 이건 유지 (레이아웃이기 때문에 클라이언트에서 동작해야 함)

import { ReactNode } from 'react';

import BottomTabBar from '@/components/common/BottomTabBar';
import DateNavigator from '@/components/ui/check/DateNavigator';
import StatsHeader from './_components/StatsHeader';
import TabMenu from '@/components/common/TabMenu';
import { useUIStore } from '@/stores/useUIStore';
import TopNav from '@/components/common/TopNav';
import { useFilterStore } from '@/stores/useFilterStore';

const tabs = [
  { key: 'expense', label: 'Expense' },
  { key: 'income', label: 'Income' },
];

export default function StatsLayout({ children }: { children: ReactNode }) {
  const transactionType = useFilterStore((s) => s.query.transactionType);

  const setQuery = useFilterStore((s) => s.setQuery);
  const getQueryString = useFilterStore((s) => s.getQueryString);

  const { hideTopNav, hideDateNav, hideStatsHeader, hideTabMenu } = useUIStore(
    (s) => s.layoutOptions
  );

  const handleTabChange = (key: string) => {
    setQuery({ transactionType: key as any }); // TransactionType 타입 추후 안전하게 강제 가능
    const syncedURL = getQueryString(true); // type 포함
    window.history.replaceState(null, '', syncedURL); // router.replace 대신 클라이언트에서 교체
  };

  return (
    <div className='min-h-screen pb-[10vh] flex flex-col h-full'>
      {!hideTopNav && <TopNav />}
      {!hideStatsHeader && <StatsHeader />}
      {!hideDateNav && <DateNavigator withTransactionType />}
      {!hideTabMenu && (
        <TabMenu
          tabs={tabs}
          active={transactionType}
          onChange={handleTabChange}
          variant='underline'
        />
      )}

      <main className='flex-1 overflow-y-auto bg-surface'>{children}</main>

      <BottomTabBar />
    </div>
  );
}
