import { ReactNode } from 'react';
import { parseLocalDate } from '@/lib/date.util';
import { GroupBy } from '@/common/types';
import { TransactionType } from '@/modules/transaction/types';
import { FilterStoreProvider } from '@/providers/FilterStoreProvider';

const validRanges: GroupBy[] = ['daily', 'weekly', 'monthly', 'yearly'];
const validTypes: TransactionType[] = ['expense', 'income'];

interface StatsPageWrapperProps {
  children: ReactNode;
  searchParams?: {
    date?: string;
    groupBy?: string;
    type?: string;
  };
}

export function StatsPageWrapper({
  children,
  searchParams,
}: StatsPageWrapperProps) {
  const { date, groupBy, type } = searchParams ?? {};

  const parsedDate = date ? parseLocalDate(date) : new Date();
  const parsedGroupBy = validRanges.includes(groupBy as GroupBy)
    ? (groupBy as GroupBy)
    : 'monthly';
  const parsedType = validTypes.includes(type as TransactionType)
    ? (type as TransactionType)
    : 'expense';

  const initialQuery = {
    date: parsedDate,
    groupBy: parsedGroupBy,
    transactionType: parsedType,
  };

  return (
    <FilterStoreProvider initialQuery={initialQuery}>
      {children}
    </FilterStoreProvider>
  );
}
