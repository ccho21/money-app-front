'use client';

import Panel from '@/components/ui/Panel';

export default function AccountDetailMonthlyPage() {
  return (
    <>
      <Panel>Monthly</Panel>
    </>
  );
}
