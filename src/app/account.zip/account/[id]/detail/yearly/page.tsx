'use client';

import Panel from '@/components/ui/Panel';

export default function AccountDetailYearlyPage() {
  return (
    <>
      <Panel>Yearly</Panel>
    </>
  );
}
