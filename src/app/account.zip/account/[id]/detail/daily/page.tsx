'use client';

import Panel from '@/components/ui/Panel';

export default function AccountDetailDailyPage() {
  return (
    <>
      <Panel>
        <Panel>
          <SummaryBox
            items={[
              {
                label: 'Income',
                value: transactionSummaryResponse.incomeTotal,
                color:
                  transactionSummaryResponse.incomeTotal > 0
                    ? 'text-[#3C50E0]'
                    : 'text-gray-400',
                prefix: '$',
              },
              {
                label: 'Exp.',
                value: transactionSummaryResponse.expenseTotal,
                color:
                  transactionSummaryResponse.expenseTotal > 0
                    ? 'text-[#fb5c4c]'
                    : 'text-gray-400',
                prefix: '$',
              },
              {
                label: 'Total',
                value:
                  transactionSummaryResponse.incomeTotal -
                  transactionSummaryResponse.expenseTotal,
                color: 'text-gray-900 dark:text-white',
                prefix: '$',
              },
            ]}
          />
        </Panel>
      </Panel>
    </>
  );
}
